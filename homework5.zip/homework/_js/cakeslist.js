var vip_ar = [
    {
        "image": "1437162.jpg",
        "name": "chocolate cake",
        "calories": "257 ",
        "price":"62"
 
        

    },
    {
        
        "name": " chocolate cake",
        "calories": "371.7",
        "price": "62",
        "image": "salted_dark_chocolate_16338_16x9.jpg"

    }
]