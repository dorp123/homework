window.onload = function () {
    createAllCakes();
  }
  
  function createAllCakes() {
  
    for (let i in vip_ar) {
      let item = vip_ar[i];
      var a = new CakeClass( item.image, item.name, item.calories, item.price);
      a.addToHtml();
    }
  
  }