function CakeClass(_img, _name, _calories, _price) {
    this.image = _img;
    this.name = _name;
    this.calories = _calories;
    this.price = _price;
    
  }
  
  CakeClass.prototype.addToHtml = function () {
    let newDiv = document.createElement("div");
    newDiv.className = "col-md-6 border";
    id_parent.appendChild(newDiv);
  
  
    newDiv.innerHTML += `<img style="width:200px;" class="float-left mr-2" src="images/${this.image}">`
    newDiv.innerHTML += `<h2>name:${this.name}</h2>`
    newDiv.innerHTML += `<div>price:${this.price}</div>`

  
    let insideDiv = document.createElement("div");
    newDiv.appendChild(insideDiv);
  
  
  
  
    newDiv.onclick = function () {
      insideDiv.innerHTML = "Calories: " + this.calories;
    }.bind(this);
  }